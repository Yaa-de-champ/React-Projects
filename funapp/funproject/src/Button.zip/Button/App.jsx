import  './index.css';
// import Main from './components/Main.jsx'


import Button from "./Button/Button.jsx"

function App() {
    return (
        <>
        <Button/>
        </>
    );
}
export default App
